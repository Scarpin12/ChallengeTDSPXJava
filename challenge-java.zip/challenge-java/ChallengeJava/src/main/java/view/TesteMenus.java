package view;

public class TesteMenus {
    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
        menu.exibirMenu();
    }
}

