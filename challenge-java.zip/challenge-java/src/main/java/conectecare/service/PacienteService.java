package conectecare.service;
import conectecare.model.DTO.PacienteDto;
import conectecare.model.Entity.Paciente;
import conectecare.model.Entity.Patologia;
import conectecare.repository.PacienteRepository;
import conectecare.repository.PatologiaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.util.List;

@ApplicationScoped
public class PacienteService {

    @Inject
    PacienteRepository pacienteRepository;

    @Inject
    PatologiaRepository patologiaRepository;

    @Inject
    ConsultaService consultaService;


    /**
     * Substitui: PacienteBo.cadastrarNovoPaciente()
     * Mesma lógica: cadastra paciente e agenda consulta automática
     */
    @Transactional
    public Paciente cadastrarNovoPaciente(PacienteDto pacienteDto) {

        // 1. Cria o paciente (equivalente ao novoPaciente no BO)
        Paciente paciente = new Paciente();
        paciente.setNome(pacienteDto.getNome());
        paciente.setCpf(pacienteDto.getCpf());
        paciente.setIdade(pacienteDto.getIdade());
        paciente.setEmail(pacienteDto.getEmail());
        paciente.setSenha(pacienteDto.getSenha());
        paciente.setTelefoneContato(pacienteDto.getTelefone());

        // 2. Busca e seta a patologia (equivalente ao patologiaEscolhida)
        if (pacienteDto.getIdPatologia() != null ) {
            Patologia patologia = patologiaRepository.findById(Long.valueOf(pacienteDto.getIdPatologia()));
            if (patologia == null) {
                throw new NotFoundException("Patologia não encontrada");
            }
            paciente.setPatologia(patologia);
        }

        // 3. Salva o paciente (equivalente ao pacienteDAO.inserirPaciente)
        pacienteRepository.persist(paciente);

        // 4. Agenda consulta automática (equivalente ao consultaBO.cadastrarConsultaAutomatica)
        consultaService.cadastrarConsultaAutomatica(paciente, pacienteDto.getIdPatologia() );

        System.out.println("Paciente cadastrado com sucesso!\n");
        System.out.println("Consulta já agendada com sucesso!\n");
        return paciente;
    }

    /**
     * Substitui: PacienteBo.atualizacaoCadastro()
     * Mesma lógica: atualiza dados do paciente
     */
    @Transactional
    public void atualizacaoCadastro(String nome, String cpf, Integer idade, String email,
                                    String telefone, Integer idPatologia, String cpfValidacao) {

        // Cria objeto paciente com novos dados (equivalente ao novoAtualizaPaciente)
        Paciente pacienteAtualizado = new Paciente();
        pacienteAtualizado.setNome(nome);
        pacienteAtualizado.setCpf(cpf);
        pacienteAtualizado.setIdade(idade);
        pacienteAtualizado.setEmail(email);
        pacienteAtualizado.setTelefoneContato(telefone);

        // Busca patologia se informada
        if (idPatologia != null) {
            Patologia patologia = patologiaRepository.findById(Long.valueOf(idPatologia));
            pacienteAtualizado.setPatologia(patologia);
        }

        // Atualiza no banco (equivalente ao pacienteDAO.atualizaPaciente)
        pacienteRepository.atualizaPaciente(pacienteAtualizado, cpfValidacao);

        System.out.println("Paciente Atualizado com sucesso!");
    }

    /**
     * Substitui: PacienteBo.listarTodosPacientes()
     * Mesma funcionalidade: lista todos os pacientes
     */
    public List<Paciente> listarTodosPacientes() {
        return pacienteRepository.listarTodosPacientes();
    }

    /**
     * Método adicional: buscar paciente por CPF
     */
    public Paciente buscarPorCpf(String cpf) {
        return pacienteRepository.findByCpf(cpf)
                .orElseThrow(() -> new NotFoundException("Paciente não encontrado"));
    }

    /**
     * Método adicional: excluir paciente por CPF
     */
    @Transactional
    public boolean excluirPaciente(String cpf) {
        return pacienteRepository.excluirPaciente(cpf);
    }
}