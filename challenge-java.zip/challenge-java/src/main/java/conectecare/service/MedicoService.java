package conectecare.service;
import conectecare.model.Entity.Medico;
import conectecare.repository.MedicoRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class MedicoService {

    @Inject
    MedicoRepository medicoRepository;

    /**
     * Cadastra um novo médico
     * USO: medicoService.cadastrarMedico(medico)
     */
    @Transactional
    public void cadastrarMedico(Medico medico) {
        // Valida se CRM já existe
        if (medicoRepository.existsByCrm(medico.getCrm())) {
            throw new RuntimeException("CRM já cadastrado");
        }

        // Valida se CPF já existe
        if (medicoRepository.existsByCpf(medico.getCpf())) {
            throw new RuntimeException("CPF já cadastrado");
        }

        // Salva o médico (INSERT automático)
        medicoRepository.persist(medico);
        System.out.println("Médico cadastrado com sucesso!");
    }

    /**
     * Lista todos os médicos ordenados por nome
     * USO: medicoService.listarTodosMedicos()
     */
    public List<Medico> listarTodosMedicos() {
        return medicoRepository.listarTodosMedicos();
    }

    /**
     * Lista médicos com suas especialidades (JOIN FETCH)
     * USO: medicoService.listarMedicosComEspecialidades()
     */
    public List<Medico> listarMedicosComEspecialidades() {
        return medicoRepository.listarMedicosComEspecialidades();
    }

    /**
     * Busca médico por ID
     * USO: medicoService.buscarPorId(1)
     */
    public Medico buscarPorId(Integer id) {
        Medico medico = medicoRepository.findById(Long.valueOf(id));
        if (medico == null) {
            throw new NotFoundException("Médico não encontrado");
        }
        return medico;
    }

    /**
     * Busca médico por CRM
     * USO: medicoService.buscarPorCrm("12345-SP")
     */
    public Medico buscarPorCrm(String crm) {
        return medicoRepository.findByCrm(crm)
                .orElseThrow(() -> new NotFoundException("Médico não encontrado com CRM: " + crm));
    }

    /**
     * Busca médico por CPF
     * USO: medicoService.buscarPorCpf("12345678901")
     */
    public Medico buscarPorCpf(String cpf) {
        return medicoRepository.findByCpf(cpf)
                .orElseThrow(() -> new NotFoundException("Médico não encontrado com CPF: " + cpf));
    }

    /**
     * Busca médicos por especialidade
     * USO: medicoService.buscarPorEspecialidade(1)
     */
    public List<Medico> buscarPorEspecialidade(Integer especialidadeId) {
        return medicoRepository.findByEspecialidadeId(especialidadeId);
    }

    /**
     * Busca médicos por nome (busca parcial)
     * USO: medicoService.buscarPorNome("Carlos")
     */
    public List<Medico> buscarPorNome(String nome) {
        return medicoRepository.findByNome(nome);
    }

    /**
     * Busca médico que trata uma patologia específica
     * USO: medicoService.buscarPorPatologia(1)
     */
    public Optional<Medico> buscarPorPatologia(Integer patologiaId) {
        return medicoRepository.findByPatologiaId(patologiaId);
    }

    /**
     * Atualiza dados de um médico
     * USO: medicoService.atualizarMedico(medico, "12345-SP")
     */
    @Transactional
    public void atualizarMedico(Medico medico, String crmValidacao) {
        medicoRepository.atualizarMedico(medico, crmValidacao);
    }

    /**
     * Exclui médico por CRM
     * USO: medicoService.excluirMedico("12345-SP")
     */
    @Transactional
    public boolean excluirMedico(String crm) {
        return medicoRepository.excluirMedico(crm);
    }

    /**
     * Verifica se CRM existe
     * USO: medicoService.crmExiste("12345-SP")
     */
    public boolean crmExiste(String crm) {
        return medicoRepository.existsByCrm(crm);
    }

    /**
     * Verifica se CPF existe
     * USO: medicoService.cpfExiste("12345678901")
     */
    public boolean cpfExiste(String cpf) {
        return medicoRepository.existsByCpf(cpf);
    }

    /**
     * Conta total de médicos cadastrados
     * USO: long total = medicoService.contarMedicos()
     */
    public long contarMedicos() {
        return medicoRepository.contarMedicos();
    }

    /**
     * Busca médico disponível para uma patologia (para agendamento automático)
     * USO: medicoService.buscarMedicoDisponivelParaPatologia(1)
     */
    public Optional<Medico> buscarMedicoDisponivelParaPatologia(Integer patologiaId) {
        return medicoRepository.findByPatologiaId(patologiaId);
    }
}