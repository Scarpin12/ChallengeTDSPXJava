package conectecare.service;
import conectecare.model.Entity.Patologia;
import conectecare.repository.PatologiaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.List;

@ApplicationScoped
public class PatologiaService {

    @Inject
    PatologiaRepository patologiaRepository;

    /**
     * Substitui: PatologiaDao.listarPatologia()
     * Mesma funcionalidade: lista todas as patologias
     */
    public List<Patologia> listarPatologia() {
        return patologiaRepository.listarPatologia();
    }

    /**
     * Método adicional: buscar patologia por ID
     */
    public Patologia buscarPorId(Integer id) {
        return patologiaRepository.findById(Long.valueOf(id));
    }

    /**
     * Método adicional: listar patologias ordenadas por nome
     */
    public List<Patologia> listarPatologiaOrdenado() {
        return patologiaRepository.listarPatologia();
    }
}