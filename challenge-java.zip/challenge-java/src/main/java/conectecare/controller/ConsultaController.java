package conectecare.controller;

public class ConsultaController {


}
