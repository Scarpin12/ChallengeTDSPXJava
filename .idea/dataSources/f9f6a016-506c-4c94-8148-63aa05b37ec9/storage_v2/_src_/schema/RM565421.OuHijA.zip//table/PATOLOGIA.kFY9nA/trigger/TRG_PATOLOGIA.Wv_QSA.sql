create trigger TRG_PATOLOGIA
    before insert
    on PATOLOGIA
    for each row
BEGIN
    IF :NEW.id_patologia IS NULL THEN
        SELECT seq_patologia.NEXTVAL INTO :NEW.id_patologia FROM DUAL;
    END IF;
END;
/

