create trigger TRG_PESSOAS
    before insert
    on PESSOAS
    for each row
BEGIN
    IF :NEW.id IS NULL THEN
        SELECT seq_pessoas.NEXTVAL INTO :NEW.id FROM DUAL;
    END IF;
END;
/

