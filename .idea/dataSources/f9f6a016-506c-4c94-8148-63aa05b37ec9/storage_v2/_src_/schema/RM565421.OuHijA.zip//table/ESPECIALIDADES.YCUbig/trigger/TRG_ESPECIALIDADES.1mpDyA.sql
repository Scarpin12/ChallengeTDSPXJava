create trigger TRG_ESPECIALIDADES
    before insert
    on ESPECIALIDADES
    for each row
BEGIN
    IF :NEW.id_especialidade IS NULL THEN
        SELECT seq_especialidades.NEXTVAL INTO :NEW.id_especialidade FROM DUAL;
    END IF;
END;
/

