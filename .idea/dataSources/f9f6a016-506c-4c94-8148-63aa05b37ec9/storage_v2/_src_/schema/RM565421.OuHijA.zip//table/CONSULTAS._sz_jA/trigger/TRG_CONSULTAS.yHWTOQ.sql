create trigger TRG_CONSULTAS
    before insert
    on CONSULTAS
    for each row
BEGIN
    IF :NEW.id IS NULL THEN
        SELECT seq_consultas.NEXTVAL INTO :NEW.id FROM DUAL;
    END IF;
END;
/

