create trigger TRG_ENDERECOS
    before insert
    on ENDERECOS
    for each row
BEGIN
    IF :NEW.id_endereco IS NULL THEN
        SELECT seq_enderecos.NEXTVAL INTO :NEW.id_endereco FROM DUAL;
    END IF;
END;
/

